<?php
require_once 'config.php'; require_login(); $pageTitle='My profile | DriveEase'; $errors=[];
$q=db()->prepare("SELECT * FROM users WHERE user_id=?"); $q->execute([$_SESSION['user']['user_id']]); $user=$q->fetch();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim($_POST['name']??''); $phone=trim($_POST['phone']??'');
    if($name==='') $errors[]='Name is required.';
    if(!preg_match('/^[0-9+\-\s]{8,15}$/',$phone)) $errors[]='Enter a valid phone number.';
    if(!$errors) {
        $u=db()->prepare("UPDATE users SET name=?,phone=? WHERE user_id=?"); $u->execute([$name,$phone,$user['user_id']]);
        $_SESSION['user']['name']=$name; $_SESSION['user']['phone']=$phone; flash('Profile updated successfully.'); header('Location: profile.php'); exit;
    }
}
require 'includes/header.php';
?>
<section class="section container narrow"><div class="form-card"><span class="eyebrow">ACCOUNT SETTINGS</span><h1>Your profile.</h1><p class="muted">Keep your contact information up to date.</p><?php if($errors): ?><div class="alert error"><?php foreach($errors as $er) echo '<div>'.e($er).'</div>'; ?></div><?php endif; ?><form method="post" class="stack-form"><label>Full name<input name="name" required value="<?= e($_POST['name']??$user['name']) ?>"></label><label>Email address<input type="email" value="<?= e($user['email']) ?>" disabled><small class="small-muted">Email cannot be changed in this demo.</small></label><label>Phone number<input name="phone" required value="<?= e($_POST['phone']??$user['phone']) ?>"></label><button class="btn btn-primary">Save changes →</button></form></div></section>
<?php require 'includes/footer.php'; ?>
