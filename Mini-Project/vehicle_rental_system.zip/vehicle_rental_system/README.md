# DriveEase — Vehicle Rental System (Web Development Mini Project)

A responsive PHP + MySQL mini project aligned with the Web Development syllabus:
- HTML5 semantic layout and forms
- CSS3 responsive UI, gradients, transitions and cards
- JavaScript DOM interaction and form validation
- PHP sessions, form processing, prepared statements and file upload
- MySQL database with CRUD-style vehicle and booking operations
- JSON endpoint for available vehicles (`api/vehicles.php`)

## Requirements
- XAMPP (Apache + PHP 8+ + MySQL/MariaDB)
- Web browser

## Setup
1. Extract the `vehicle_rental_system` folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** from the XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Import `database.sql` (choose the file or copy/paste its SQL).
5. Open `http://localhost/vehicle_rental_system/`.

## Demo accounts
After importing `database.sql`:
- Admin: `admin@driveease.local` / `password`
- Customer: `demo@driveease.local` / `password`

For this academic demo, demo password hashes are created by the setup helper when first used. If login fails on an environment that handles hashes differently, visit:
`http://localhost/vehicle_rental_system/setup_demo.php`
then sign in. Delete `setup_demo.php` after setup.

## Features
- Home page and vehicle listing/search
- Customer signup/login/logout
- Vehicle detail and booking form
- My bookings and cancellation
- Profile editing
- Admin dashboard: add/edit/delete vehicles, view bookings, update booking status
- Receipt-like booking confirmation
- Vehicle image upload for admin (optional)
- JSON API: `api/vehicles.php`
- Server-side validation and PDO prepared statements

## Notes
This is a college mini-project starter, not a production rental/payment system. Payments are simulated; no real money is collected. For production, add CSRF protection, email verification, real payment gateway integration, stronger deployment configuration, audit logging, and full authorization review.
