<?php
require_once 'config.php';
if (is_logged_in()) { header('Location: index.php'); exit; }
$pageTitle='Log in | DriveEase'; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email=strtolower(trim($_POST['email']??'')); $password=$_POST['password']??'';
    $q=db()->prepare("SELECT * FROM users WHERE email=? LIMIT 1"); $q->execute([$email]); $user=$q->fetch();
    if ($user && password_verify($password,$user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user']=['user_id'=>(int)$user['user_id'],'name'=>$user['name'],'email'=>$user['email'],'phone'=>$user['phone'],'role'=>$user['role']];
        flash('Welcome back, '.$user['name'].'!'); header('Location: '.($user['role']==='admin'?'admin.php':'index.php')); exit;
    } else $error='Email or password is incorrect.';
}
require 'includes/header.php';
?>
<section class="auth-section"><div class="auth-art"><span class="eyebrow">GOOD TO SEE YOU AGAIN</span><h2>Keys ready.<br><span>Let's go.</span></h2><p>Sign in to pick up where you left off and manage your upcoming journeys.</p><div class="auth-art-badge">↗ &nbsp; Your trips, all in one place.</div></div><div class="auth-form-wrap"><form class="auth-form" method="post"><span class="eyebrow">WELCOME BACK</span><h1>Log in.</h1><p class="muted">Access your DriveEase account.</p><?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?><label>Email address<input type="email" name="email" required autocomplete="email" placeholder="you@example.com" value="<?= e($_POST['email']??'') ?>"></label><label>Password<input type="password" name="password" required autocomplete="current-password" placeholder="Your password"></label><button class="btn btn-primary btn-full">Log in →</button><p class="auth-switch">New to DriveEase? <a href="register.php">Create an account</a></p><p class="small-muted">Demo: demo@driveease.local / password</p></form></div></section>
<?php require 'includes/footer.php'; ?>
