<?php
require_once 'config.php';
try {
    $pdo=db();
    $accounts=[
      ['DriveEase Admin','admin@driveease.local','9999999999','password','admin'],
      ['Demo Customer','demo@driveease.local','9876543210','password','customer']
    ];
    foreach($accounts as $a) {
        $q=$pdo->prepare("SELECT user_id FROM users WHERE email=?"); $q->execute([$a[1]]);
        if(!$q->fetch()) {
            $ins=$pdo->prepare("INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?,?)");
            $ins->execute([$a[0],$a[1],$a[2],password_hash($a[3],PASSWORD_DEFAULT),$a[4]]);
        } else {
            $up=$pdo->prepare("UPDATE users SET password_hash=? WHERE email=?");
            $up->execute([password_hash('password',PASSWORD_DEFAULT),$a[1]]);
        }
    }
    echo "Demo accounts are ready. Admin: admin@driveease.local / password; Customer: demo@driveease.local / password. Delete setup_demo.php now.";
} catch(Throwable $e) { http_response_code(500); echo "Setup failed. Import database.sql first. Details: ".htmlspecialchars($e->getMessage()); }
