<?php
require_once 'config.php';
$_SESSION=[]; session_regenerate_id(true); flash('You have been logged out.'); header('Location: index.php'); exit;
