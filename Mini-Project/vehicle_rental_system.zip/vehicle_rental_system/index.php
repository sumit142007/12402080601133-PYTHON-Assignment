<?php
require_once 'config.php';
$pageTitle = 'DriveEase | Rent a vehicle with ease';
try {
    $stmt = db()->query("SELECT * FROM vehicles WHERE status='Available' ORDER BY featured DESC, vehicle_id DESC LIMIT 3");
    $featuredVehicles = $stmt->fetchAll();
} catch (Throwable $t) { $featuredVehicles = []; }
require 'includes/header.php';
?>
<section class="hero">
  <div class="hero-shape shape-one"></div><div class="hero-shape shape-two"></div>
  <div class="container hero-grid">
    <div class="hero-copy">
      <span class="eyebrow"><span class="eyebrow-dot"></span> YOUR JOURNEY, YOUR RULES</span>
      <h1>Find your road.<br><span>Feel the freedom.</span></h1>
      <p>From quick city trips to weekend escapes, find a ride that fits your plan and your budget.</p>
      <div class="hero-actions"><a class="btn btn-primary" href="vehicles.php">Explore vehicles <span>↗</span></a><a class="btn btn-ghost" href="#how-it-works">How it works</a></div>
      <div class="hero-stats"><div><strong>24/7</strong><span>Online booking</span></div><div><strong>Easy</strong><span>Pickup process</span></div><div><strong>Clear</strong><span>Rental pricing</span></div></div>
    </div>
    <div class="hero-visual">
      <div class="visual-label"><span class="pulse"></span> READY FOR YOUR NEXT TRIP</div>
      <div class="car-illustration"><div class="sun"></div><svg viewBox="0 0 650 300" role="img" aria-label="Illustration of a rental car"><defs><linearGradient id="carPaint" x1="0" x2="1"><stop stop-color="#ffb86c"/><stop offset="1" stop-color="#f36f43"/></linearGradient></defs><ellipse cx="320" cy="258" rx="250" ry="18" fill="#172b45" opacity=".12"/><path d="M100 198 L128 153 Q144 133 183 126 L248 70 Q265 54 301 54 L400 54 Q431 56 455 85 L512 145 Q550 157 568 181 L581 211 L570 234 L86 234 L78 214 Z" fill="url(#carPaint)"/><path d="M184 124 L254 75 Q267 66 296 66 L335 66 L335 124 Z" fill="#d9f0f5"/><path d="M350 66 L397 66 Q421 69 440 92 L470 124 L350 124 Z" fill="#d9f0f5"/><path d="M335 67 L335 125" stroke="#fff" stroke-width="5" opacity=".7"/><path d="M121 177 L170 177" stroke="#fff0d6" stroke-width="10" stroke-linecap="round"/><path d="M508 173 L547 183" stroke="#fff6cf" stroke-width="10" stroke-linecap="round"/><rect x="249" y="153" width="85" height="8" rx="4" fill="#d75e39"/><circle cx="178" cy="228" r="42" fill="#263447"/><circle cx="178" cy="228" r="23" fill="#dce3e9"/><circle cx="178" cy="228" r="10" fill="#7d8c9d"/><circle cx="480" cy="228" r="42" fill="#263447"/><circle cx="480" cy="228" r="23" fill="#dce3e9"/><circle cx="480" cy="228" r="10" fill="#7d8c9d"/></svg></div>
      <div class="visual-card"><div class="visual-icon">✦</div><div><strong>Made for the way you move</strong><span>Find your perfect match</span></div><span class="visual-arrow">↗</span></div>
    </div>
  </div>
</section>
<section class="search-band">
  <form class="container search-form" action="vehicles.php" method="get">
    <label><span>⌕</span><div><small>VEHICLE TYPE</small><select name="type"><option value="">All vehicle types</option><option>Car</option><option>SUV</option><option>Bike</option><option>Van</option></select></div></label>
    <label><span>▦</span><div><small>PICKUP DATE</small><input type="date" name="start_date" min="<?= date('Y-m-d') ?>"></div></label>
    <label><span>▦</span><div><small>RETURN DATE</small><input type="date" name="end_date" min="<?= date('Y-m-d') ?>"></div></label>
    <button class="btn btn-primary" type="submit">Find a vehicle <span>→</span></button>
  </form>
</section>
<section class="section container">
  <div class="section-heading"><div><span class="eyebrow">PICK YOUR RIDE</span><h2>Popular <span class="text-accent">choices.</span></h2><p>Comfort, style and value for every kind of trip.</p></div><a class="text-link" href="vehicles.php">View all vehicles ↗</a></div>
  <div class="vehicle-grid">
  <?php if ($featuredVehicles): foreach ($featuredVehicles as $v): ?>
    <article class="vehicle-card">
      <a class="vehicle-image" href="vehicle.php?id=<?= (int)$v['vehicle_id'] ?>">
        <?php if (!empty($v['image'])): ?><img src="<?= e($v['image']) ?>" alt="<?= e($v['model']) ?>"><?php else: ?><div class="vehicle-placeholder <?= e(strtolower($v['type'])) ?>"><span><?= e(strtoupper(substr($v['type'],0,1))) ?></span><b><?= e($v['model']) ?></b></div><?php endif; ?>
        <span class="tag"><?= e($v['type']) ?></span>
      </a>
      <div class="vehicle-info"><div class="vehicle-title"><h3><?= e($v['brand'].' '.$v['model']) ?></h3><span class="rating">★ 4.9</span></div><p><?= e($v['transmission']) ?> · <?= (int)$v['seats'] ?> seats · <?= e($v['fuel_type']) ?></p><div class="vehicle-price"><div><strong><?= money($v['daily_rate']) ?></strong><span>/ day</span></div><a class="btn btn-small btn-dark" href="vehicle.php?id=<?= (int)$v['vehicle_id'] ?>">View details</a></div></div>
    </article>
  <?php endforeach; else: ?>
    <div class="empty-state"><h3>Vehicles are being prepared</h3><p>Import database.sql and reload the page to see the demo fleet.</p><a class="btn btn-primary" href="vehicles.php">Browse fleet</a></div>
  <?php endif; ?>
  </div>
</section>
<section class="section how-section" id="how-it-works"><div class="container"><div class="section-heading centered"><div><span class="eyebrow">NO COMPLICATIONS</span><h2>Three steps. <span class="text-accent">One great trip.</span></h2><p>Getting on the road should be the easiest part of your day.</p></div></div><div class="steps-grid"><article class="step-card"><span class="step-number">01</span><div class="step-icon">⌕</div><h3>Find your ride</h3><p>Browse vehicles and compare features, rates and availability.</p></article><article class="step-card"><span class="step-number">02</span><div class="step-icon">▣</div><h3>Book in minutes</h3><p>Choose your rental dates and submit a simple booking request.</p></article><article class="step-card"><span class="step-number">03</span><div class="step-icon">↗</div><h3>Enjoy the journey</h3><p>Track your booking and coordinate pickup with rental staff.</p></article></div></div></section>
<section class="cta-section container"><div><span class="eyebrow">YOUR NEXT ADVENTURE STARTS HERE</span><h2>Good trips start with<br>the right ride.</h2><p>Browse the fleet and find a vehicle that feels right.</p><a href="vehicles.php" class="btn btn-light">Explore the fleet ↗</a></div><div class="cta-decoration">D<span>RIVE</span></div></section>
<?php require 'includes/footer.php'; ?>
