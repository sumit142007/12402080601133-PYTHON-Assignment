CREATE DATABASE IF NOT EXISTS vehicle_rental CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vehicle_rental;

CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vehicles (
  vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
  brand VARCHAR(60) NOT NULL,
  model VARCHAR(80) NOT NULL,
  type ENUM('Car','SUV','Bike','Van') NOT NULL DEFAULT 'Car',
  registration_no VARCHAR(30) NOT NULL UNIQUE,
  daily_rate DECIMAL(10,2) NOT NULL,
  seats TINYINT UNSIGNED NOT NULL DEFAULT 4,
  fuel_type ENUM('Petrol','Diesel','Electric','Hybrid') NOT NULL DEFAULT 'Petrol',
  transmission ENUM('Manual','Automatic') NOT NULL DEFAULT 'Manual',
  status ENUM('Available','Rented','Maintenance') NOT NULL DEFAULT 'Available',
  description TEXT,
  image VARCHAR(255) DEFAULT NULL,
  featured TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  vehicle_id INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  status ENUM('Pending','Confirmed','Active','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_booking_customer FOREIGN KEY (customer_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_booking_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id) ON DELETE RESTRICT,
  INDEX idx_booking_dates (vehicle_id,start_date,end_date,status)
);

CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_mode ENUM('UPI','Card','Cash') NOT NULL DEFAULT 'UPI',
  status ENUM('Pending','Successful','Failed','Refunded') NOT NULL DEFAULT 'Pending',
  transaction_id VARCHAR(80) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_payment_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

INSERT IGNORE INTO vehicles (vehicle_id,brand,model,type,registration_no,daily_rate,seats,fuel_type,transmission,status,description,featured) VALUES
(1,'Maruti Suzuki','Swift','Car','GJ01DE1001',1500,5,'Petrol','Manual','Available','A compact and efficient hatchback, ideal for city travel and weekend plans.',1),
(2,'Hyundai','Creta','SUV','GJ01DE1002',2800,5,'Diesel','Automatic','Available','A comfortable SUV with generous space for a family trip.',1),
(3,'Royal Enfield','Classic 350','Bike','GJ01DE1003',900,2,'Petrol','Manual','Available','A classic motorcycle for relaxed rides and scenic routes.',1),
(4,'Honda','City','Car','GJ01DE1004',2200,5,'Petrol','Automatic','Available','A refined sedan with a comfortable cabin for longer drives.',0),
(5,'Kia','Carens','Van','GJ01DE1005',3200,7,'Diesel','Manual','Available','A spacious people-mover for group trips and family outings.',0),
(6,'Tata','Nexon EV','SUV','GJ01DE1006',2600,5,'Electric','Automatic','Available','An electric SUV for smooth, quiet and modern city travel.',0);
