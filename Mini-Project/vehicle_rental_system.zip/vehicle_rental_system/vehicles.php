<?php
require_once 'config.php';
$pageTitle = 'Browse Vehicles | DriveEase';
$type = trim($_GET['type'] ?? '');
$q = trim($_GET['q'] ?? '');
$start = $_GET['start_date'] ?? '';
$end = $_GET['end_date'] ?? '';
$vehicles = [];
try {
    $sql = "SELECT v.* FROM vehicles v WHERE v.status='Available'";
    $params = [];
    if ($type !== '') { $sql .= " AND v.type = ?"; $params[] = $type; }
    if ($q !== '') { $sql .= " AND (v.brand LIKE ? OR v.model LIKE ? OR v.type LIKE ?)"; $like = "%$q%"; array_push($params,$like,$like,$like); }
    if ($start && $end) {
        $sql .= " AND v.vehicle_id NOT IN (SELECT b.vehicle_id FROM bookings b WHERE b.status IN ('Pending','Confirmed','Active') AND NOT (b.end_date < ? OR b.start_date > ?))";
        array_push($params, $start, $end);
    }
    $sql .= " ORDER BY v.featured DESC, v.daily_rate ASC";
    $stmt = db()->prepare($sql); $stmt->execute($params); $vehicles = $stmt->fetchAll();
} catch (Throwable $t) {}
require 'includes/header.php';
?>
<section class="page-hero"><div class="container"><span class="eyebrow">THE DRIVE EASE COLLECTION</span><h1>Find your <span class="text-accent">perfect ride.</span></h1><p>Choose from our collection of cars, SUVs, bikes and more.</p></div></section>
<section class="section container">
  <form class="filter-bar" method="get"><label class="search-input">⌕ <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search brand, model or type"></label><select name="type"><option value="">All types</option><?php foreach(['Car','SUV','Bike','Van'] as $t): ?><option <?= $type===$t?'selected':'' ?>><?= $t ?></option><?php endforeach; ?></select><input type="date" name="start_date" min="<?= date('Y-m-d') ?>" value="<?= e($start) ?>" aria-label="Start date"><input type="date" name="end_date" min="<?= date('Y-m-d') ?>" value="<?= e($end) ?>" aria-label="End date"><button class="btn btn-primary" type="submit">Search</button><a class="btn btn-ghost" href="vehicles.php">Reset</a></form>
  <div class="results-line"><strong><?= count($vehicles) ?> vehicles found</strong><span>Rates shown per day</span></div>
  <div class="vehicle-grid">
  <?php foreach($vehicles as $v): ?>
    <article class="vehicle-card"><a class="vehicle-image" href="vehicle.php?id=<?= (int)$v['vehicle_id'] ?>"><?php if ($v['image']): ?><img src="<?= e($v['image']) ?>" alt="<?= e($v['brand'].' '.$v['model']) ?>"><?php else: ?><div class="vehicle-placeholder <?= e(strtolower($v['type'])) ?>"><span><?= e(strtoupper(substr($v['type'],0,1))) ?></span><b><?= e($v['brand'].' '.$v['model']) ?></b></div><?php endif; ?><span class="tag"><?= e($v['type']) ?></span></a><div class="vehicle-info"><div class="vehicle-title"><h3><?= e($v['brand'].' '.$v['model']) ?></h3><span class="rating">★ 4.9</span></div><p><?= e($v['transmission']) ?> · <?= (int)$v['seats'] ?> seats · <?= e($v['fuel_type']) ?></p><div class="vehicle-price"><div><strong><?= money($v['daily_rate']) ?></strong><span>/ day</span></div><a class="btn btn-small btn-dark" href="vehicle.php?id=<?= (int)$v['vehicle_id'] ?>">View details</a></div></div></article>
  <?php endforeach; ?>
  </div>
  <?php if (!$vehicles): ?><div class="empty-state"><div class="empty-icon">⌕</div><h3>No matching vehicles</h3><p>Try changing your search or dates.</p><a class="btn btn-primary" href="vehicles.php">Clear filters</a></div><?php endif; ?>
</section>
<?php require 'includes/footer.php'; ?>
