<?php
$pageTitle = $pageTitle ?? 'DriveEase | Vehicle Rental';
$flashMessage = take_flash();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="DriveEase vehicle rental management system mini project">
  <title><?= e($pageTitle) ?></title>
  <link rel="stylesheet" href="assets/css/style.css">
  <script defer src="assets/js/app.js"></script>
</head>
<body>
<header class="site-header">
  <div class="container nav-wrap">
    <a class="brand" href="index.php"><span class="brand-mark">D</span><span>Drive<span class="brand-accent">Ease</span><small>MOVE YOUR WAY</small></span></a>
    <button class="menu-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
    <nav class="main-nav">
      <a href="index.php">Home</a>
      <a href="vehicles.php">Vehicles</a>
      <?php if (is_logged_in()): ?>
        <a href="my_bookings.php">My Bookings</a>
        <a href="profile.php">Profile</a>
        <?php if (is_admin()): ?><a href="admin.php">Admin</a><?php endif; ?>
        <a class="nav-cta" href="logout.php">Logout</a>
      <?php else: ?>
        <a href="login.php">Login</a>
        <a class="nav-cta" href="register.php">Get Started</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main>
<?php if ($flashMessage): ?>
  <div class="container"><div class="alert <?= e($flashMessage['type']) ?>"><?= e($flashMessage['message']) ?></div></div>
<?php endif; ?>
