</main>
<footer class="site-footer">
  <div class="container footer-grid">
    <div><a class="brand footer-brand" href="index.php"><span class="brand-mark">D</span><span>Drive<span class="brand-accent">Ease</span><small>MOVE YOUR WAY</small></span></a><p>Simple, reliable rides for every journey.</p></div>
    <div><strong>Explore</strong><a href="vehicles.php">Browse vehicles</a><a href="my_bookings.php">My bookings</a></div>
    <div><strong>Project</strong><p>Web Development Mini Project</p><p>PHP · MySQL · HTML · CSS · JavaScript</p></div>
  </div>
  <div class="container footer-bottom">© <?= date('Y') ?> DriveEase. Educational demo project.</div>
</footer>
</body>
</html>
