<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
try {
    $type = trim($_GET['type'] ?? '');
    $sql = "SELECT vehicle_id,brand,model,type,daily_rate,seats,fuel_type,transmission,status FROM vehicles WHERE status='Available'";
    $params=[];
    if ($type!=='') { $sql .= " AND type=?"; $params[]=$type; }
    $sql .= " ORDER BY featured DESC, daily_rate ASC";
    $q=db()->prepare($sql); $q->execute($params);
    echo json_encode(['success'=>true,'count'=>$q->rowCount(),'vehicles'=>$q->fetchAll()], JSON_PRETTY_PRINT);
} catch(Throwable $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'Unable to retrieve vehicles.']);
}
