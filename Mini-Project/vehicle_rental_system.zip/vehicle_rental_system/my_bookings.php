<?php
require_once 'config.php'; require_login(); $pageTitle='My bookings | DriveEase';
if (isset($_POST['cancel_id'])) {
    $id=(int)$_POST['cancel_id'];
    $q=db()->prepare("UPDATE bookings SET status='Cancelled' WHERE booking_id=? AND customer_id=? AND status IN ('Pending','Confirmed') AND start_date > CURDATE()");
    $q->execute([$id,$_SESSION['user']['user_id']]);
    flash($q->rowCount()?'Booking cancelled successfully.':'This booking can no longer be cancelled.',$q->rowCount()?'success':'error');
    header('Location: my_bookings.php'); exit;
}
$q=db()->prepare("SELECT b.*,v.brand,v.model,v.type,v.registration_no FROM bookings b JOIN vehicles v ON v.vehicle_id=b.vehicle_id WHERE b.customer_id=? ORDER BY b.created_at DESC");
$q->execute([$_SESSION['user']['user_id']]); $bookings=$q->fetchAll();
require 'includes/header.php';
?>
<section class="page-hero"><div class="container"><span class="eyebrow">YOUR DRIVE, ORGANIZED</span><h1>My <span class="text-accent">bookings.</span></h1><p>Review your trips and keep track of each reservation.</p></div></section>
<section class="section container"><div class="table-wrap"><table class="data-table"><thead><tr><th>Booking</th><th>Vehicle</th><th>Rental dates</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach($bookings as $b): ?><tr><td>#<?= (int)$b['booking_id'] ?><small><?= e($b['created_at']) ?></small></td><td><strong><?= e($b['brand'].' '.$b['model']) ?></strong><small><?= e($b['type']) ?></small></td><td><?= e($b['start_date']) ?><small>to <?= e($b['end_date']) ?></small></td><td><?= money($b['total_amount']) ?></td><td><span class="status status-<?= e(strtolower($b['status'])) ?>"><?= e($b['status']) ?></span></td><td><?php if(in_array($b['status'],['Pending','Confirmed'],true) && $b['start_date']>date('Y-m-d')): ?><form method="post" data-confirm="Cancel this booking?"><input type="hidden" name="cancel_id" value="<?= (int)$b['booking_id'] ?>"><button class="text-button danger-text">Cancel</button></form><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php if(!$bookings): ?><div class="empty-state"><div class="empty-icon">▣</div><h3>No bookings yet</h3><p>Your next journey is waiting.</p><a class="btn btn-primary" href="vehicles.php">Browse vehicles</a></div><?php endif; ?></section>
<?php require 'includes/footer.php'; ?>
