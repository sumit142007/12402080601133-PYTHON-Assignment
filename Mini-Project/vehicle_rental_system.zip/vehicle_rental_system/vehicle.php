<?php
require_once 'config.php';
$id = filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT);
$stmt = db()->prepare("SELECT * FROM vehicles WHERE vehicle_id=?"); $stmt->execute([$id]); $vehicle = $stmt->fetch();
if (!$vehicle) { http_response_code(404); exit('Vehicle not found. <a href="vehicles.php">Browse vehicles</a>'); }
$pageTitle = $vehicle['brand'].' '.$vehicle['model'].' | DriveEase';
$errors = [];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_login();
    $start = $_POST['start_date'] ?? ''; $end = $_POST['end_date'] ?? '';
    $today = date('Y-m-d');
    if (!$start || !$end || $start < $today || $end < $start) $errors[] = 'Please select valid rental dates.';
    if (!$errors) {
        $check = db()->prepare("SELECT COUNT(*) FROM bookings WHERE vehicle_id=? AND status IN ('Pending','Confirmed','Active') AND NOT (end_date < ? OR start_date > ?)");
        $check->execute([$id,$start,$end]);
        if ((int)$check->fetchColumn() > 0) $errors[] = 'This vehicle is already booked for those dates.';
    }
    if (!$errors) {
        $days = max(1,(int)((strtotime($end)-strtotime($start))/86400)+1);
        $amount = $days * (float)$vehicle['daily_rate'];
        $ins = db()->prepare("INSERT INTO bookings (customer_id,vehicle_id,start_date,end_date,total_amount,status) VALUES (?,?,?,?,?,'Pending')");
        $ins->execute([$_SESSION['user']['user_id'],$id,$start,$end,$amount]);
        $bookingId = (int)db()->lastInsertId();
        header('Location: checkout.php?id='.$bookingId); exit;
    }
}
require 'includes/header.php';
?>
<section class="section container detail-layout">
  <div class="detail-main"><a class="back-link" href="vehicles.php">← Back to vehicles</a><div class="detail-image"><?php if ($vehicle['image']): ?><img src="<?= e($vehicle['image']) ?>" alt="<?= e($vehicle['brand'].' '.$vehicle['model']) ?>"><?php else: ?><div class="vehicle-placeholder large <?= e(strtolower($vehicle['type'])) ?>"><span><?= e(strtoupper(substr($vehicle['type'],0,1))) ?></span><b><?= e($vehicle['brand'].' '.$vehicle['model']) ?></b></div><?php endif; ?></div><span class="eyebrow"><?= e($vehicle['type']) ?> COLLECTION</span><h1><?= e($vehicle['brand'].' '.$vehicle['model']) ?></h1><p class="detail-description"><?= e($vehicle['description']) ?></p><div class="spec-grid"><div><span>♙</span><strong><?= (int)$vehicle['seats'] ?> seats</strong></div><div><span>⚙</span><strong><?= e($vehicle['transmission']) ?></strong></div><div><span>⛽</span><strong><?= e($vehicle['fuel_type']) ?></strong></div><div><span>✓</span><strong><?= e($vehicle['status']) ?></strong></div></div></div>
  <aside class="booking-panel"><span class="eyebrow">MAKE IT YOURS</span><h2>Reserve this ride</h2><div class="booking-rate"><strong><?= money($vehicle['daily_rate']) ?></strong><span>/ day</span></div>
  <?php if ($errors): ?><div class="alert error"><?php foreach($errors as $er) echo '<div>'.e($er).'</div>'; ?></div><?php endif; ?>
  <form method="post" class="stack-form" data-date-form><label>Pickup date<input required type="date" name="start_date" min="<?= date('Y-m-d') ?>" value="<?= e($_POST['start_date'] ?? $_GET['start_date'] ?? '') ?>"></label><label>Return date<input required type="date" name="end_date" min="<?= date('Y-m-d') ?>" value="<?= e($_POST['end_date'] ?? $_GET['end_date'] ?? '') ?>"></label><div class="form-note">Rental total is calculated by calendar days. Payment is simulated for this academic demo.</div><button class="btn btn-primary btn-full" type="submit">Continue to booking →</button><?php if (!is_logged_in()): ?><p class="small-muted">You'll be asked to sign in before booking.</p><?php endif; ?></form>
  </aside>
</section>
<?php require 'includes/footer.php'; ?>
