document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('nav-open');
      toggle.setAttribute('aria-expanded', String(open));
    });
  }

  document.querySelectorAll('[data-confirm]').forEach(form => {
    form.addEventListener('submit', event => {
      const message = form.getAttribute('data-confirm') || 'Are you sure?';
      if (!window.confirm(message)) event.preventDefault();
    });
  });

  document.querySelectorAll('[data-date-form]').forEach(form => {
    const start = form.querySelector('[name="start_date"]');
    const end = form.querySelector('[name="end_date"]');
    if (start && end) {
      start.addEventListener('change', () => {
        end.min = start.value || new Date().toISOString().slice(0,10);
        if (end.value && end.value < start.value) end.value = start.value;
      });
    }
  });

  document.querySelectorAll('input[type="file"][data-file-name]').forEach(input => {
    input.addEventListener('change', () => {
      const target = document.getElementById(input.dataset.fileName);
      if (target) target.textContent = input.files.length ? input.files[0].name : 'No file selected';
    });
  });
});
