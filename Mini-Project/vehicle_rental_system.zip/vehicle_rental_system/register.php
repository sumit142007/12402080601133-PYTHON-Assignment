<?php
require_once 'config.php';
if (is_logged_in()) { header('Location: index.php'); exit; }
$pageTitle = 'Create account | DriveEase'; $errors=[];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim($_POST['name']??''); $email=strtolower(trim($_POST['email']??'')); $phone=trim($_POST['phone']??''); $password=$_POST['password']??'';
    if ($name==='') $errors[]='Name is required.';
    if (!filter_var($email,FILTER_VALIDATE_EMAIL)) $errors[]='Enter a valid email address.';
    if (!preg_match('/^[0-9+\-\s]{8,15}$/',$phone)) $errors[]='Enter a valid phone number.';
    if (strlen($password)<6) $errors[]='Password must be at least 6 characters.';
    if (!$errors) {
        $q=db()->prepare("SELECT user_id FROM users WHERE email=?"); $q->execute([$email]);
        if ($q->fetch()) $errors[]='An account with this email already exists.';
        else {
            $q=db()->prepare("INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?, 'customer')");
            $q->execute([$name,$email,$phone,password_hash($password,PASSWORD_DEFAULT)]);
            flash('Account created. Please log in.'); header('Location: login.php'); exit;
        }
    }
}
require 'includes/header.php';
?>
<section class="auth-section"><div class="auth-art"><span class="eyebrow">WELCOME ABOARD</span><h2>Your next journey<br>starts <span>here.</span></h2><p>Create your account to reserve vehicles, manage bookings and keep your plans in one place.</p><div class="auth-art-badge">✦ &nbsp; Simple booking. More freedom.</div></div><div class="auth-form-wrap"><form class="auth-form" method="post"><span class="eyebrow">CREATE YOUR ACCOUNT</span><h1>Let's get moving.</h1><p class="muted">Enter your details to get started.</p><?php if($errors): ?><div class="alert error"><?php foreach($errors as $er) echo '<div>'.e($er).'</div>'; ?></div><?php endif; ?><label>Full name<input name="name" required autocomplete="name" value="<?= e($_POST['name']??'') ?>" placeholder="e.g. Rahul Patel"></label><label>Email address<input type="email" name="email" required autocomplete="email" value="<?= e($_POST['email']??'') ?>" placeholder="you@example.com"></label><label>Phone number<input name="phone" required value="<?= e($_POST['phone']??'') ?>" placeholder="+91 98765 43210"></label><label>Password<input type="password" name="password" required minlength="6" autocomplete="new-password" placeholder="At least 6 characters"></label><button class="btn btn-primary btn-full">Create account →</button><p class="auth-switch">Already have an account? <a href="login.php">Log in</a></p></form></div></section>
<?php require 'includes/footer.php'; ?>
