<?php
require_once 'config.php'; require_login();
$id=filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT);
$q=db()->prepare("SELECT b.*,v.brand,v.model,v.type,v.daily_rate,u.name FROM bookings b JOIN vehicles v ON v.vehicle_id=b.vehicle_id JOIN users u ON u.user_id=b.customer_id WHERE b.booking_id=? AND b.customer_id=?");
$q->execute([$id,$_SESSION['user']['user_id']]); $booking=$q->fetch();
if (!$booking) { http_response_code(404); exit('Booking not found.'); }
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $mode=$_POST['payment_mode']??'UPI';
    if (!in_array($mode,['UPI','Card','Cash'],true)) $mode='UPI';
    try {
        db()->beginTransaction();
        $lock=db()->prepare("SELECT status FROM bookings WHERE booking_id=? FOR UPDATE"); $lock->execute([$id]); $current=$lock->fetchColumn();
        if ($current==='Pending') {
            $p=db()->prepare("INSERT INTO payments (booking_id,amount,payment_mode,status,transaction_id) VALUES (?,?,?,'Successful',?)");
            $p->execute([$id,$booking['total_amount'],$mode,'DEMO'.strtoupper(bin2hex(random_bytes(4)))]);
            $u=db()->prepare("UPDATE bookings SET status='Confirmed' WHERE booking_id=?"); $u->execute([$id]);
        }
        db()->commit(); flash('Demo payment successful. Booking confirmed.'); header('Location: my_bookings.php'); exit;
    } catch(Throwable $t) { if(db()->inTransaction()) db()->rollBack(); $error='Unable to complete demo payment. Please retry.'; }
}
$pageTitle='Checkout | DriveEase'; require 'includes/header.php';
?>
<section class="section container narrow"><a class="back-link" href="vehicle.php?id=<?= (int)$booking['vehicle_id'] ?>">← Back to vehicle</a><div class="checkout-card"><span class="eyebrow">FINAL STEP</span><h1>Confirm your booking.</h1><p class="muted">Review the details below before completing the demo checkout.</p><?php if(!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?><div class="checkout-summary"><div><span>Vehicle</span><strong><?= e($booking['brand'].' '.$booking['model']) ?></strong></div><div><span>Pickup</span><strong><?= e($booking['start_date']) ?></strong></div><div><span>Return</span><strong><?= e($booking['end_date']) ?></strong></div><div><span>Booking ID</span><strong>#<?= (int)$booking['booking_id'] ?></strong></div><div class="summary-total"><span>Total rental amount</span><strong><?= money($booking['total_amount']) ?></strong></div></div><form method="post" class="stack-form"><label>Demo payment method<select name="payment_mode"><option>UPI</option><option>Card</option><option>Cash</option></select></label><div class="alert info">This is a college demo. No real payment will be charged.</div><button class="btn btn-primary btn-full">Pay & confirm booking →</button></form></div></section>
<?php require 'includes/footer.php'; ?>
